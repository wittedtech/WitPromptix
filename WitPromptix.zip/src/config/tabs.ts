export const tabs = [
  { name: 'Grok', color: 'gray-500' },
  { name: 'ChatGPT', color: 'green-500' },
  { name: 'Gemini', color: 'blue-500' },
];