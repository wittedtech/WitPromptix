export const sidebarOptions = [
  'LinkedIn Post Generation Prompt',
  'Article Writing Prompt',
  'X Post Generator Prompt',
  'YouTube Video Script Generation Prompt',
  'Research Prompt',
  'Prompt for Learning Specific Topic',
];