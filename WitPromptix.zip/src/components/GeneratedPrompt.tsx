import React from 'react';

interface GeneratedPromptProps {
  prompt: string;
  onBack: () => void;
}

const GeneratedPrompt: React.FC<GeneratedPromptProps> = ({ prompt, onBack }) => (
  <div className="bg-gray-800 p-6 rounded-lg shadow-lg fade-in">
    <h2 className="text-xl font-semibold mb-4 text-teal-400">Generated Prompt</h2>
    <pre className="bg-gray-700 p-4 rounded text-gray-300 whitespace-pre-wrap">
      {prompt}
    </pre>
    <button
      className="mt-4 bg-teal-500 text-white px-4 py-2 rounded hover:bg-teal-600"
      onClick={onBack}
    >
      Back to Form
    </button>
  </div>
);

export default GeneratedPrompt;