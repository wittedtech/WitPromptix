import React, { useState } from 'react';
import { sidebarOptions } from '../config/sidebarOptions';

interface SidebarProps {
  setSelectedOption: (option: string | null) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ setSelectedOption }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <button
        className="md:hidden fixed top-20 left-4 z-50 p-2 bg-secondary-bg rounded-md text-primary-text"
        onClick={() => setIsOpen(!isOpen)}
      >
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="2"
            d="M4 6h16M4 12h16m-7 6h7"
          />
        </svg>
      </button>
      <div
        className={`fixed md:static top-0 left-0 h-full w-64 bg-secondary-bg p-4 transform ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        } md:translate-x-0 transition-transform duration-300 z-40`}
      >
        <h2 className="text-lg font-semibold mb-4 text-accent">Prompt Options</h2>
        <ul>
          {sidebarOptions.map((option) => (
            <li
              key={option}
              className="p-2 hover:bg-gray-700 dark:hover:bg-gray-600 rounded cursor-pointer text-primary-text hover:text-accent"
              onClick={() => {
                setSelectedOption(option);
                setIsOpen(false);
              }}
            >
              {option}
            </li>
          ))}
        </ul>
      </div>
      {isOpen && (
        <div
          className="fixed inset-0 bg-black opacity-50 md:hidden"
          onClick={() => setIsOpen(false)}
        ></div>
      )}
    </>
  );
};

export default Sidebar;