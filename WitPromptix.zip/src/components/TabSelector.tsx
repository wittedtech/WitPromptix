import React from 'react';
import { tabs } from '../config/tabs';

interface TabSelectorProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const TabSelector: React.FC<TabSelectorProps> = ({ activeTab, setActiveTab }) => (
  <div className="flex flex-col sm:flex-row justify-center bg-secondary-bg p-2 space-y-2 sm:space-y-0 sm:space-x-2">
    {tabs.map((tab) => (
      <button
        key={tab.name}
        className={`px-4 py-2 rounded-md text-sm sm:text-base font-medium transition-all ${
          activeTab === tab.name
            ? `bg-${tab.color} text-white`
            : 'bg-gray-700 dark:bg-gray-600 text-primary-text hover:bg-gray-600 dark:hover:bg-gray-500'
        }`}
        onClick={() => setActiveTab(tab.name)}
      >
        {tab.name}
      </button>
    ))}
  </div>
);

export default TabSelector;